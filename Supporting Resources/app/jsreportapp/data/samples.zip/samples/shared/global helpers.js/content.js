function toJSON (data) {
  return JSON.stringify(data);
}
